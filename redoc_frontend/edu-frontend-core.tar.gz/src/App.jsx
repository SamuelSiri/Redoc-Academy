import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useAuth } from './hooks/useAuth';
import MainLayout from './components/layout/MainLayout';
import ProtectedRoute from './components/common/ProtectedRoute';

// Pages
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/student/DashboardPage';
import TeacherDashboard from './pages/teacher/TeacherDashboard';
import BrowsePage from './pages/student/BrowsePage';
import ResourceViewPage from './pages/student/ResourceViewPage';
import UploadPage from './pages/teacher/UploadPage';
import MyUploadsPage from './pages/teacher/MyUploadsPage';
import ManageCategoriesPage from './pages/teacher/ManageCategoriesPage';
import NotFoundPage from './pages/NotFoundPage';

const App = () => {
  const { checkAuth, isAuthenticated, isTeacher } = useAuth();

  useEffect(() => {
    checkAuth();
  }, []);

  return (
    <BrowserRouter>
      <Toaster position="top-right" toastOptions={{ style: { fontFamily: 'inherit', fontSize: 14, fontWeight: 600 } }} />
      <Routes>
        {/* Auth — sin layout */}
        <Route path="/login" element={isAuthenticated ? <Navigate to="/" /> : <LoginPage />} />
        <Route path="/register" element={isAuthenticated ? <Navigate to="/" /> : <RegisterPage />} />

        {/* App — con layout */}
        <Route element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
          <Route path="/" element={isTeacher ? <TeacherDashboard /> : <DashboardPage />} />
          <Route path="/browse" element={<BrowsePage />} />
          <Route path="/resource/:id" element={<ResourceViewPage />} />

          <Route path="/teacher/upload" element={<ProtectedRoute requiredRole="TEACHER"><UploadPage /></ProtectedRoute>} />
          <Route path="/teacher/my-uploads" element={<ProtectedRoute requiredRole="TEACHER"><MyUploadsPage /></ProtectedRoute>} />
          <Route path="/teacher/categories" element={<ProtectedRoute requiredRole="TEACHER"><ManageCategoriesPage /></ProtectedRoute>} />
        </Route>

        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
