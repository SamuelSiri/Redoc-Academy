import './BrowsePage.css';
const BrowsePage = () => (
  <div><h1 style={{fontSize:24,fontWeight:700,color:'#1c1d1f',marginBottom:8}}>Explorar recursos</h1><p style={{color:'#6a6f73',fontSize:14}}>Próximamente — buscador con filtros por categoría</p></div>
);
export default BrowsePage;
