import { useAuth } from '../../hooks/useAuth';
import { Link } from 'react-router-dom';
import './DashboardPage.css';

const DashboardPage = () => {
  const { user } = useAuth();

  const recentResources = [
    { id: 1, title: 'Introducción a JavaScript ES6+', type: 'PDF', category: 'Programación', date: 'Hace 2 días' },
    { id: 2, title: 'Configuración de Redes LAN', type: 'Video', category: 'Redes', date: 'Hace 3 días' },
    { id: 3, title: 'Diagrama ER - Sistema de Ventas', type: 'Imagen', category: 'Base de Datos', date: 'Hace 5 días' },
    { id: 4, title: 'Fórmulas de Cálculo Diferencial', type: 'PDF', category: 'Cálculo', date: 'Hace 1 semana' },
  ];

  return (
    <div className="sd">
      <div className="sd-header">
        <h1>Hola, {user?.name?.split(' ')[0]}</h1>
        <p>Explora los recursos disponibles para ti</p>
      </div>

      <div className="sd-stats">
        <div className="sd-stat">
          <span className="sd-stat-val">142</span>
          <span className="sd-stat-label">Recursos disponibles</span>
        </div>
        <div className="sd-stat">
          <span className="sd-stat-val">8</span>
          <span className="sd-stat-label">Categorías</span>
        </div>
        <div className="sd-stat">
          <span className="sd-stat-val">12</span>
          <span className="sd-stat-label">Descargados</span>
        </div>
      </div>

      <div className="sd-section">
        <div className="sd-section-head">
          <h2>Recursos recientes</h2>
          <Link to="/browse" className="sd-viewall">Ver todos</Link>
        </div>
        <div className="sd-list">
          {recentResources.map((r) => (
            <Link to={`/resource/${r.id}`} key={r.id} className="sd-item">
              <div className={`sd-item-type sd-item-type--${r.type.toLowerCase()}`}>{r.type}</div>
              <div className="sd-item-info">
                <span className="sd-item-title">{r.title}</span>
                <span className="sd-item-meta">{r.category} · {r.date}</span>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
