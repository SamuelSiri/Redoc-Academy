import './ResourceView.css';
const ResourceViewPage = () => (
  <div><h1 style={{fontSize:24,fontWeight:700,color:'#1c1d1f',marginBottom:8}}>Detalle del recurso</h1><p style={{color:'#6a6f73',fontSize:14}}>Próximamente — vista detallada con descarga</p></div>
);
export default ResourceViewPage;
