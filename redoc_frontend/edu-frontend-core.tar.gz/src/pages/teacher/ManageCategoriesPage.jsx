import './ManageCategories.css';
const ManageCategoriesPage = () => (
  <div><h1 style={{fontSize:24,fontWeight:700,color:'#1c1d1f',marginBottom:8}}>Categorías</h1><p style={{color:'#6a6f73',fontSize:14}}>Próximamente — gestión de categorías y subcategorías</p></div>
);
export default ManageCategoriesPage;
