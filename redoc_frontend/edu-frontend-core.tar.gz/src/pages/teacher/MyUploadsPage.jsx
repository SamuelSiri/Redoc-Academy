import './MyUploadsPage.css';
const MyUploadsPage = () => (
  <div><h1 style={{fontSize:24,fontWeight:700,color:'#1c1d1f',marginBottom:8}}>Mis recursos</h1><p style={{color:'#6a6f73',fontSize:14}}>Próximamente — tabla con tus recursos subidos</p></div>
);
export default MyUploadsPage;
