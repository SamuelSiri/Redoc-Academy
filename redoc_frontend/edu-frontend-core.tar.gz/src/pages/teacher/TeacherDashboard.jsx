import { useAuth } from '../../hooks/useAuth';
import { Link } from 'react-router-dom';
import './TeacherDashboard.css';

const TeacherDashboard = () => {
  const { user } = useAuth();

  return (
    <div className="td">
      <div className="td-header">
        <h1>Bienvenido, {user?.name?.split(' ').pop()}</h1>
        <p>Panel de administración de recursos educativos</p>
      </div>

      <div className="td-stats">
        <div className="td-stat">
          <div className="td-stat-icon td-stat-icon--purple">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          </div>
          <div>
            <span className="td-stat-val">24</span>
            <span className="td-stat-label">Recursos subidos</span>
          </div>
        </div>
        <div className="td-stat">
          <div className="td-stat-icon td-stat-icon--blue">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          </div>
          <div>
            <span className="td-stat-val">156</span>
            <span className="td-stat-label">Estudiantes activos</span>
          </div>
        </div>
        <div className="td-stat">
          <div className="td-stat-icon td-stat-icon--green">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          </div>
          <div>
            <span className="td-stat-val">1,240</span>
            <span className="td-stat-label">Descargas totales</span>
          </div>
        </div>
        <div className="td-stat">
          <div className="td-stat-icon td-stat-icon--amber">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
          </div>
          <div>
            <span className="td-stat-val">8</span>
            <span className="td-stat-label">Categorías</span>
          </div>
        </div>
      </div>

      <div className="td-actions">
        <h2>Acciones rápidas</h2>
        <div className="td-actions-grid">
          <Link to="/teacher/upload" className="td-action">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            <span>Subir recurso</span>
          </Link>
          <Link to="/teacher/my-uploads" className="td-action">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            <span>Mis recursos</span>
          </Link>
          <Link to="/teacher/categories" className="td-action">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
            <span>Categorías</span>
          </Link>
          <Link to="/browse" className="td-action">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <span>Explorar</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;
