import './UploadPage.css';
const UploadPage = () => (
  <div><h1 style={{fontSize:24,fontWeight:700,color:'#1c1d1f',marginBottom:8}}>Subir recurso</h1><p style={{color:'#6a6f73',fontSize:14}}>Próximamente — formulario drag & drop</p></div>
);
export default UploadPage;
