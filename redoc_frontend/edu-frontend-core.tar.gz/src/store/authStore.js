import { create } from 'zustand';

const MOCK_USERS = {
  'teacher@eduplatform.com': { id: 1, name: 'Prof. María García', email: 'teacher@eduplatform.com', role: 'TEACHER' },
  'student@eduplatform.com': { id: 2, name: 'Carlos Martínez', email: 'student@eduplatform.com', role: 'STUDENT' },
  'admin@eduplatform.com':   { id: 3, name: 'Administrador', email: 'admin@eduplatform.com', role: 'ADMIN' },
};

const useAuthStore = create((set) => ({
  user: JSON.parse(localStorage.getItem('edu_user') || 'null'),
  isAuthenticated: !!localStorage.getItem('edu_user'),
  loading: false,

  login: async ({ email, password }) => {
    await new Promise((r) => setTimeout(r, 500));
    const user = MOCK_USERS[email];
    if (!user || password !== 'admin123') {
      throw { response: { data: { message: 'Credenciales inválidas' } } };
    }
    localStorage.setItem('edu_user', JSON.stringify(user));
    set({ user, isAuthenticated: true });
    return user;
  },

  register: async ({ name, email, password }) => {
    await new Promise((r) => setTimeout(r, 500));
    if (MOCK_USERS[email]) {
      throw { response: { data: { message: 'El email ya está registrado' } } };
    }
    const user = { id: Date.now(), name, email, role: 'STUDENT' };
    localStorage.setItem('edu_user', JSON.stringify(user));
    set({ user, isAuthenticated: true });
    return user;
  },

  logout: () => {
    localStorage.removeItem('edu_user');
    set({ user: null, isAuthenticated: false });
  },

  checkAuth: () => {
    const saved = localStorage.getItem('edu_user');
    if (saved) {
      set({ user: JSON.parse(saved), isAuthenticated: true, loading: false });
    } else {
      set({ loading: false });
    }
  },
}));

export default useAuthStore;
